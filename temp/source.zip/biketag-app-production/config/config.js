module.exports = {
    public: {
        imgur: ['albumHash', 'queueHash'],
        reddit: ['subreddit'],
    },
    rendering: {
        overrideViewEngine: ['liquid', 'ejs'],
    },
    compilation: true,
}
